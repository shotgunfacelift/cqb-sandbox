import pygame
from constants import BTN_C, BTN_HOV, BTN_ACT, TEXT_C, TEXT_DIM

font_ui   = None
font_sm   = None
font_tiny = None


def init_fonts():
    global font_ui, font_sm, font_tiny
    # Built in pygame font
    font_ui   = pygame.font.Font(None, 22)
    font_sm   = pygame.font.Font(None, 20)
    font_tiny = pygame.font.Font(None, 17)


def draw_btn(surf, rect, lbl, active=False, hover=False):
    col = BTN_ACT if active else (BTN_HOV if hover else BTN_C)
    pygame.draw.rect(surf, col, rect, border_radius=5)
    pygame.draw.rect(surf, (70, 70, 88), rect, 1, border_radius=5)
    t = font_sm.render(lbl, True, TEXT_C)
    surf.blit(t, (rect.centerx - t.get_width() // 2,
                  rect.centery - t.get_height() // 2))


def draw_slider(surf, rect, val, lo, hi):
    pygame.draw.rect(surf, (44, 44, 56), rect, border_radius=4)
    if hi > lo:
        f  = (val - lo) / (hi - lo)
        fw = max(0, int(f * rect.w))
        pygame.draw.rect(surf, (55, 105, 170),
                         pygame.Rect(rect.x, rect.y, fw, rect.h),
                         border_radius=4)
        hx = rect.x + fw
        pygame.draw.circle(surf, (150, 195, 255), (hx, rect.centery), 8)