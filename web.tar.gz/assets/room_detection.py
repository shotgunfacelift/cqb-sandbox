from collections import defaultdict
from constants import GRID, DOOR_W, DOOR_H
from math_utils import snap, v2len


def detect_rooms(walls, doors):
    if not walls:
        return []
    h_blocked = set()
    v_blocked = set()
    for w in walls:
        if w.y1 == w.y2:
            y = w.y1 // GRID
            for x in range(w.x1 // GRID, w.x2 // GRID):
                h_blocked.add((x, y))
        else:
            x = w.x1 // GRID
            for y in range(w.y1 // GRID, w.y2 // GRID):
                v_blocked.add((x, y))
    for d in doors:
        if d.horizontal:
            h_blocked.discard((d.x // GRID, d.y // GRID))
        else:
            v_blocked.discard((d.x // GRID, d.y // GRID))
    all_xs  = [w.x1 for w in walls] + [w.x2 for w in walls]
    all_ys  = [w.y1 for w in walls] + [w.y2 for w in walls]
    min_col = min(all_xs) // GRID - 1
    max_col = max(all_xs) // GRID + 1
    min_row = min(all_ys) // GRID - 1
    max_row = max(all_ys) // GRID + 1
    visited = {}
    rooms   = []
    def bfs(sc, sr, rid):
        q = [(sc, sr)]
        visited[(sc, sr)] = rid
        cells = set()
        while q:
            nq = []
            for (cx, cy) in q:
                cells.add((cx, cy))
                for nx, ny, bset, bkey in [
                    (cx, cy-1, h_blocked, (cx, cy-1)),
                    (cx, cy+1, h_blocked, (cx, cy  )),
                    (cx-1, cy, v_blocked, (cx-1, cy)),
                    (cx+1, cy, v_blocked, (cx,   cy)),
                ]:
                    if nx < min_col or nx > max_col or ny < min_row or ny > max_row:
                        continue
                    if (nx, ny) in visited or bkey in bset:
                        continue
                    visited[(nx, ny)] = rid
                    nq.append((nx, ny))
            q = nq
        return cells
    rid   = 0
    seeds = [(d.x // GRID, d.y // GRID) for d in doors]
    seeds.append(((min_col + max_col) // 2, (min_row + max_row) // 2))
    for sc, sr in seeds:
        if (sc, sr) not in visited:
            cells = bfs(sc, sr, rid)
            if cells:
                avg_x = sum(c * GRID + GRID // 2 for c, r in cells) / len(cells)
                avg_y = sum(r * GRID + GRID // 2 for c, r in cells) / len(cells)
                rooms.append({'id': rid, 'cells': cells, 'centre': (avg_x, avg_y), 'portals': []})
                rid += 1
    for d in doors:
        dc_col, dc_row = d.x // GRID, d.y // GRID
        assigned = set()
        for r in rooms:
            if (dc_col, dc_row) in r['cells']:
                r['portals'].append(d)
                assigned.add(r['id'])
        if not assigned:
            best = min(rooms, key=lambda r: v2len(
                r['centre'][0] - (d.x + DOOR_W // 2),
                r['centre'][1] - (d.y + DOOR_W // 2)), default=None)
            if best:
                best['portals'].append(d)
    return rooms


def build_room_graph(rooms, doors):
    door_rooms = defaultdict(list)
    for r in rooms:
        for d in r['portals']:
            door_rooms[id(d)].append(r['id'])
    adj = defaultdict(list)
    for d in doors:
        rlist = door_rooms[id(d)]
        if len(rlist) == 2:
            a, b = rlist
            adj[a].append((b, d))
            adj[b].append((a, d))
        elif len(rlist) == 1:
            adj[rlist[0]].append((-1, d))
    return adj


def room_of_point(px, py, rooms):
    col, row = int(px) // GRID, int(py) // GRID
    for r in rooms:
        if (col, row) in r['cells']:
            return r['id']
    if not rooms:
        return -1
    return min(rooms, key=lambda r: v2len(r['centre'][0] - px, r['centre'][1] - py))['id']