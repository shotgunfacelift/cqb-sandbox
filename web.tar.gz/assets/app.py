import math
import sys
import pygame

from constants import (
    SCREEN_W, SCREEN_H, GRID, WALL_T, FPS,
    BG, GRID_C, WALL_SEL, ENEMY_C, E_RADIUS,
    PANEL_C, TEXT_DIM, LASER_C,
    WALL_C, WINDOW_C, DOOR_C, DOOR_ENTRY, TEAM_COLOR,
    PANEL_H, SIDEBAR_W,
    Tool, DoorType,
)
from math_utils import snap, v2len, build_wall_segs, get_door_gap_indices, get_window_gap_indices
from entities import Wall, Door, Window, Enemy, Teammate, SimFrame
from room_detection import detect_rooms
from simulation import run_simulation
import ui
from ui import init_fonts, draw_btn, draw_slider


class App:
    def __init__(self, w=SCREEN_W, h=SCREEN_H):
        self.screen = pygame.display.set_mode((w, h), pygame.RESIZABLE)
        pygame.display.set_caption("CQB Sandbox")
        self.clock  = pygame.time.Clock()
        init_fonts()

        self.offset = [SIDEBAR_W + 30, PANEL_H + 30]
        self.zoom   = 1.0
        self.panning   = False
        self.pan_start = (0, 0)
        self.pan_off0  = (0, 0)
        self.sim_speed  = 4.0
        self._frame_acc = 0.0

        self.tool         = Tool.SELECT
        self.placing_wall = False
        self.wall_start   = None
        self._space_held        = False   # Space+LMB = pan (MMB alternative for web)
        self._space_held_panning = False   # True when panning via space+LMB

        self.walls   : list[Wall]   = []
        self.doors   : list[Door]   = []
        self.windows : list[Window] = []
        self.enemies : list[Enemy]  = []
        self.entry_door: Door | None = None
        self.drag_obj = None
        self.drag_off = (0, 0)

        self.frames    : list[SimFrame] = []
        self.playing    = False
        self.frame_idx  = 0
        self.recorded   = False

        self._wall_segs   = []
        self._door_gaps   = set()
        self._window_gaps = set()
        self._rooms       = []

        self._status_msg   = ""
        self._status_timer = 0

        # Pending JSON from browser file-input
        self._pending_load = None

        sw, sh = self.screen.get_size()
        self._fov_surf = pygame.Surface((max(1, sw - SIDEBAR_W), max(1, sh - PANEL_H)),
                                        pygame.SRCALPHA)

        # Detect web environment and inject JS helpers
        self._is_web = sys.platform in ('emscripten', 'wasi')
        if self._is_web:
            self._web_setup()

    # Web JS setup
    def _web_setup(self):
        try:
            from platform import window
            window.eval("""
                (function(){
                    var c = document.querySelector('canvas');
                    if (!c) return;
                    // Prevent middle-click from scrolling the page
                    c.addEventListener('mousedown', function(e){
                        if (e.button === 1) e.preventDefault();
                    }, {passive: false});
                    // Prevent right-click context menu on canvas
                    c.addEventListener('contextmenu', function(e){
                        e.preventDefault();
                    }, {passive: false});
                })();
                // Hidden file input for Load button
                (function(){
                    if (document.getElementById('_cqb_inp')) return;
                    var inp = document.createElement('input');
                    inp.type = 'file';
                    inp.id = '_cqb_inp';
                    inp.accept = '.json,application/json';
                    inp.style.display = 'none';
                    inp.addEventListener('change', function(){
                        var f = inp.files[0];
                        if (!f) return;
                        var r = new FileReader();
                        r.onload = function(e){ window._cqb_json = e.target.result; };
                        r.readAsText(f);
                        inp.value = '';
                    });
                    document.body.appendChild(inp);
                    window._cqb_json = null;
                })();
            """)
        except Exception as e:
            print(f"[web_setup] {e}")

    # Geometry cache
    def _rebuild_geo(self):
        self._wall_segs   = build_wall_segs(self.walls)
        self._door_gaps   = get_door_gap_indices(self._wall_segs, self.doors)
        self._window_gaps = get_window_gap_indices(self._wall_segs, self.windows)
        self._rooms       = detect_rooms(self.walls, self.doors)

    # Coordinate helpers
    def world(self, mx, my):
        return (mx - self.offset[0]) / self.zoom, (my - self.offset[1]) / self.zoom

    def in_canvas(self, mx, my):
        return mx > SIDEBAR_W and my > PANEL_H

    def obj_at(self, mx, my):
        wx, wy = self.world(mx, my)
        for e in reversed(self.enemies):
            if e.hit(wx, wy): return e, 'enemy'
        for d in reversed(self.doors):
            if d.hit(wx, wy): return d, 'door'
        for w in reversed(self.windows):
            if w.hit(wx, wy): return w, 'window'
        for w in reversed(self.walls):
            if w.hit(wx, wy): return w, 'wall'
        return None, None

    def guess_horiz(self, wx, wy):
        best, bh = 999, True
        for w in self.walls:
            if w.y1 == w.y2:
                d = abs(wy - w.y1)
                if d < best: best, bh = d, True
            else:
                d = abs(wx - w.x1)
                if d < best: best, bh = d, False
        return bh

    # Events
    def handle_events(self):
        mx, my = pygame.mouse.get_pos()
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit          # safe on both desktop and wasm
            if ev.type == pygame.VIDEORESIZE:
                sw, sh = ev.size
                cw = max(1, sw - SIDEBAR_W)
                ch = max(1, sh - PANEL_H)
                self._fov_surf = pygame.Surface((cw, ch), pygame.SRCALPHA)
            if ev.type == pygame.KEYDOWN:
                ks = {pygame.K_s: Tool.SELECT, pygame.K_w: Tool.WALL,
                      pygame.K_d: Tool.DOOR,   pygame.K_e: Tool.ENTRY,
                      pygame.K_n: Tool.WINDOW,  pygame.K_x: Tool.ENEMY}
                if ev.key in ks:
                    self.tool = ks[ev.key]; self.placing_wall = False
                if ev.key == pygame.K_ESCAPE:
                    self.tool = Tool.SELECT; self.placing_wall = False
                if ev.key == pygame.K_DELETE:
                    self._delete_selected()
                if ev.key == pygame.K_SPACE:
                    self._space_held = True
                    # Only toggle play if LMB isn't held (which would mean pan)
                    if not pygame.mouse.get_pressed()[0]:
                        self.toggle_play()
            if ev.type == pygame.KEYUP:
                if ev.key == pygame.K_SPACE:
                    self._space_held = False
                    self._space_held_panning = False
                    self.panning = False
            if ev.type == pygame.MOUSEBUTTONDOWN: self.mouse_down(ev, mx, my)
            if ev.type == pygame.MOUSEBUTTONUP:   self.mouse_up(ev, mx, my)
            if ev.type == pygame.MOUSEMOTION:     self.mouse_move(ev, mx, my)
            if ev.type == pygame.MOUSEWHEEL:
                if mx > SIDEBAR_W and my > PANEL_H:
                    factor = 1.1 if ev.y > 0 else (1 / 1.1)
                    new_z  = max(0.2, min(5.0, self.zoom * factor))
                    wx_cur = (mx - self.offset[0]) / self.zoom
                    wy_cur = (my - self.offset[1]) / self.zoom
                    self.offset[0] = mx - wx_cur * new_z
                    self.offset[1] = my - wy_cur * new_z
                    self.zoom = new_z

    def mouse_down(self, ev, mx, my):
        # MMB pan or Space+LMB pan
        if ev.button == 2 or (ev.button == 1 and self._space_held):
            self.panning = True
            self.pan_start = (mx, my)
            self.pan_off0  = tuple(self.offset)
            if ev.button == 1:
                self._space_held_panning = True
            return
        if my < PANEL_H:   self._panel_click(mx, my); return
        if mx < SIDEBAR_W: self._side_click(mx, my);  return
        if ev.button == 3:
            obj, typ = self.obj_at(mx, my)
            if obj: self._remove(obj, typ); self._rebuild_geo()
            return
        if ev.button != 1: return
        wx, wy = self.world(mx, my)

        if self.tool == Tool.SELECT:
            obj, typ = self.obj_at(mx, my)
            if obj:
                self.drag_obj = (obj, typ)
                if typ == 'wall': obj.selected = True; self.drag_off = (wx-obj.x1, wy-obj.y1)
                else:             self.drag_off = (wx-obj.x, wy-obj.y)
            else:
                for w in self.walls: w.selected = False
                self.drag_obj = None

        elif self.tool == Tool.WALL:
            if not self.placing_wall:
                self.placing_wall = True; self.wall_start = (snap(wx), snap(wy))
            else:
                sx, sy = self.wall_start; ex, ey = snap(wx), snap(wy)
                if abs(ex-sx) >= abs(ey-sy): ey = sy
                else:                         ex = sx
                if ex != sx or ey != sy:
                    self.walls.append(Wall(sx, sy, ex, ey)); self._rebuild_geo()
                self.placing_wall = False; self.wall_start = None

        elif self.tool == Tool.DOOR:
            h = self.guess_horiz(wx, wy)
            self.doors.append(Door(wx, wy, h, DoorType.ROOM)); self._rebuild_geo()

        elif self.tool == Tool.ENTRY:
            h = self.guess_horiz(wx, wy)
            self.doors = [d for d in self.doors if d.dtype != DoorType.ENTRY]
            d = Door(wx, wy, h, DoorType.ENTRY)
            self.entry_door = d; self.doors.append(d); self._rebuild_geo()

        elif self.tool == Tool.WINDOW:
            h = self.guess_horiz(wx, wy)
            self.windows.append(Window(wx, wy, h))

        elif self.tool == Tool.ENEMY:
            self.enemies.append(Enemy(wx, wy))

    def mouse_up(self, ev, mx, my):
        if ev.button == 2 or (ev.button == 1 and self.panning):
            self.panning = False; return
        if ev.button == 1:
            self.drag_obj   = None
            self.entry_door = next((d for d in self.doors if d.dtype == DoorType.ENTRY), None)
            self._rebuild_geo()

    def mouse_move(self, ev, mx, my):
        if self.panning:
            self.offset[0] = self.pan_off0[0] + mx - self.pan_start[0]
            self.offset[1] = self.pan_off0[1] + my - self.pan_start[1]
            return
        if self.drag_obj:
            obj, typ = self.drag_obj; wx, wy = self.world(mx, my); ox, oy = self.drag_off
            if typ == 'wall':
                nx, ny = snap(wx-ox), snap(wy-oy)
                dx, dy = nx-obj.x1, ny-obj.y1
                obj.x1 += dx; obj.y1 += dy; obj.x2 += dx; obj.y2 += dy
            elif typ in ('door', 'window'):
                obj.x, obj.y = snap(wx-ox), snap(wy-oy)
            elif typ == 'enemy':
                obj.x, obj.y = wx-ox, wy-oy

        if pygame.mouse.get_pressed()[0] and my < PANEL_H and self.recorded and self.frames:
            sr = self._slider_rect()
            if sr and sr.inflate(0, 24).collidepoint(mx, my):
                frac = max(0, min(1, (mx-sr.x)/sr.w))
                self.frame_idx = int(frac * (len(self.frames)-1))
                self.playing = False
            spr = self._speed_slider_rect()
            if spr and spr.inflate(0, 24).collidepoint(mx, my):
                frac2 = max(0.0, min(1.0, (mx-spr.x)/spr.w))
                self.sim_speed = math.exp(math.log(0.25) + frac2*(math.log(10.0)-math.log(0.25)))

    def _remove(self, obj, typ):
        if typ == 'wall':    self.walls   = [w for w in self.walls   if w is not obj]
        elif typ == 'door':  self.doors   = [d for d in self.doors   if d is not obj]
        elif typ == 'window':self.windows = [w for w in self.windows if w is not obj]
        elif typ == 'enemy': self.enemies = [e for e in self.enemies if e is not obj]

    def _delete_selected(self):
        self.walls = [w for w in self.walls if not w.selected]; self._rebuild_geo()

    # Panel/sidebar
    def _speed_slider_rect(self):
        sw, _ = self.screen.get_size()
        bw = 84; pad = 8; gap = 6
        x = pad + 4.5*(bw+gap) + 8
        w = 120
        if x + w > sw - 8: return None
        return pygame.Rect(x, (PANEL_H-12)//2, w, 12)
    
    def _slider_rect(self):
        spr = self._speed_slider_rect()
        if spr is None: return None
        sw, _ = self.screen.get_size()
        x = spr.right + 50
        w = min(260, sw - x - 8)
        if w < 40: return None
        return pygame.Rect(x, spr.y, w, 12)

    def _panel_buttons(self):
        bw, bh = 84, 34; pad = 8; gap = 6; y = (PANEL_H-bh)//2
        x = pad
        btns = []
        btns.append((pygame.Rect(x, y, bw, bh), "Reset",  self.reset));         x += bw+gap
        btns.append((pygame.Rect(x, y, bw, bh), "Play",   self.toggle_play));   x += bw+gap
        btns.append((pygame.Rect(x, y, bw, bh), "Save",   self.save_scenario)); x += bw+gap
        btns.append((pygame.Rect(x, y, bw, bh), "Load",   self.load_scenario))
        return btns

    def _panel_click(self, mx, my):
        for rect, lbl, cb in self._panel_buttons():
            if rect.collidepoint(mx, my): cb(); return

    def _side_click(self, mx, my):
        tools = [(Tool.SELECT,"Select","S"), (Tool.WALL,"Wall","W"),
                 (Tool.DOOR,"Door","D"),     (Tool.ENTRY,"Entry","E"),
                 (Tool.WINDOW,"Window","N"), (Tool.ENEMY,"Enemy","X")]
        bh = 36; pad = 8; y = PANEL_H+10
        for i, (tool, lbl, key) in enumerate(tools):
            r = pygame.Rect(pad, y+i*(bh+4), SIDEBAR_W-pad*2, bh)
            if r.collidepoint(mx, my):
                self.tool = tool; self.placing_wall = False

    # Save/load
    def _scenario_data(self):
        import json
        return json.dumps({
            "walls":   [{"x1": w.x1, "y1": w.y1, "x2": w.x2, "y2": w.y2} for w in self.walls],
            "doors":   [{"x": d.x, "y": d.y, "horizontal": d.horizontal,
                         "dtype": d.dtype.value} for d in self.doors],
            "windows": [{"x": w.x, "y": w.y, "horizontal": w.horizontal} for w in self.windows],
            "enemies": [{"x": e.x, "y": e.y, "angle": e.angle} for e in self.enemies],
        }, indent=2)

    def save_scenario(self):
        json_str = self._scenario_data()
        if self._is_web:
            try:
                from platform import window
                # Escape backtick and backslash so JS template literal is safe
                safe = json_str.replace('\\', '\\\\').replace('`', '\\`')
                window.eval(f"""
                    (function(){{
                        var b = new Blob([`{safe}`], {{type:'application/json'}});
                        var u = URL.createObjectURL(b);
                        var a = document.createElement('a');
                        a.href = u; a.download = 'scenario.json';
                        document.body.appendChild(a); a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(u);
                    }})();
                """)
            except Exception as e:
                print(f"[save] {e}")
        else:
            import os
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scenario.json")
            with open(path, "w") as f:
                f.write(json_str)
            print(f"Saved: {path}")
        self._status_msg   = "Saved → scenario.json"
        self._status_timer = FPS * 3

    def load_scenario(self):
        if self._is_web:
            try:
                from platform import window
                window.eval("document.getElementById('_cqb_inp').click();")
                self._status_msg   = "Choose a .json file…"
                self._status_timer = FPS * 3
            except Exception as e:
                print(f"[load] {e}")
        else:
            import json, os
            path = None
            try:
                import tkinter, tkinter.filedialog
                root = tkinter.Tk(); root.withdraw()
                path = tkinter.filedialog.askopenfilename(
                    title="Load scenario",
                    filetypes=[("JSON", "*.json"), ("All", "*.*")])
                root.destroy()
            except Exception:
                pass
            if not path:
                path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scenario.json")
            if not os.path.exists(path):
                print("No scenario.json found."); return
            try:
                with open(path) as f:
                    data = json.load(f)
                self._load_data(data)
                self._status_msg   = f"Loaded: {os.path.basename(path)}"
                self._status_timer = FPS * 3
            except Exception as ex:
                print(f"Load failed: {ex}")

    def load_from_json_string(self, json_str):
        import json
        try:
            self._load_data(json.loads(json_str))
        except Exception as ex:
            print(f"JSON parse failed: {ex}")

    def _load_data(self, data):
        self.reset()
        for w in data.get("walls", []):
            self.walls.append(Wall(w["x1"], w["y1"], w["x2"], w["y2"]))
        for d in data.get("doors", []):
            dt = DoorType.ENTRY if d["dtype"] == "entry" else DoorType.ROOM
            self.doors.append(Door(d["x"], d["y"], d["horizontal"], dt))
        for w in data.get("windows", []):
            self.windows.append(Window(w["x"], w["y"], w["horizontal"]))
        for e in data.get("enemies", []):
            en = Enemy(e["x"], e["y"]); en.angle = e.get("angle", math.pi)
            self.enemies.append(en)
        self.entry_door = next((d for d in self.doors if d.dtype == DoorType.ENTRY), None)
        self._rebuild_geo()

    def reset(self):
        self.walls = []; self.doors = []; self.windows = []; self.enemies = []
        self.entry_door = None; self.frames = []; self.playing = False
        self.frame_idx  = 0;    self.recorded = False; self.placing_wall = False
        self.drag_obj   = None
        self._rooms = []; self._wall_segs = []; self._door_gaps = set(); self._window_gaps = set()
        Wall._id = Door._id = Window._id = Enemy._id = 0

    def toggle_play(self):
        if not self.recorded:
            self.frames   = run_simulation(self.entry_door, self.enemies,
                                           self.walls, self.doors, self.windows)
            self.recorded = bool(self.frames)
            self.frame_idx = 0
        if self.recorded:
            self.playing = not self.playing

    # Update
    def update(self):
        # Poll for JSON loaded via browser file-input
        if self._is_web:
            try:
                from platform import window
                val = window._cqb_json
                if val:
                    self._pending_load = str(val)
                    window._cqb_json = None
            except Exception:
                pass
        if self._pending_load is not None:
            self.load_from_json_string(self._pending_load)
            self._pending_load = None
            self._status_msg   = "Scenario loaded"
            self._status_timer = FPS * 3

        if self.playing and self.frames:
            self._frame_acc += self.sim_speed
            steps = int(self._frame_acc)
            self._frame_acc -= steps
            self.frame_idx  += steps
            if self.frame_idx >= len(self.frames):
                self.frame_idx = len(self.frames) - 1
                self.playing   = False
                self._frame_acc = 0.0

    # Draw
    def draw(self):
        sw, sh = self.screen.get_size()
        cw, ch = max(1, sw - SIDEBAR_W), max(1, sh - PANEL_H)
        if self._fov_surf.get_size() != (cw, ch):
            self._fov_surf = pygame.Surface((cw, ch), pygame.SRCALPHA)
        self.screen.fill(BG)
        self._draw_canvas(sw, sh)
        self._draw_sidebar(sw, sh)
        self._draw_panel(sw, sh)
        pygame.display.flip()

    def _draw_canvas(self, sw, sh):
        cw, ch = max(1, sw - SIDEBAR_W), max(1, sh - PANEL_H)
        canvas = self.screen.subsurface(pygame.Rect(SIDEBAR_W, PANEL_H, cw, ch))
        z  = self.zoom
        ox = self.offset[0] - SIDEBAR_W
        oy = self.offset[1] - PANEL_H

        world_w    = max(1, int(math.ceil(cw / z)) + 2)
        world_h    = max(1, int(math.ceil(ch / z)) + 2)
        world_surf = pygame.Surface((world_w, world_h))
        world_surf.fill(BG)

        wx_off = int(ox / z)
        wy_off = int(oy / z)
        woff   = (wx_off, wy_off)

        gs_px     = GRID * z
        first_col = math.floor(-ox / gs_px)
        first_row = math.floor(-oy / gs_px)
        col = first_col
        while True:
            x = int(round(col * gs_px + ox))
            if x > world_w: break
            pygame.draw.line(world_surf, GRID_C, (x, 0), (x, world_h))
            col += 1
        row = first_row
        while True:
            y = int(round(row * gs_px + oy))
            if y > world_h: break
            pygame.draw.line(world_surf, GRID_C, (0, y), (world_w, y))
            row += 1

        for w in self.walls: w.draw(world_surf, woff)
        if self.placing_wall and self.wall_start:
            mxp, myp = pygame.mouse.get_pos()
            wxp, wyp = self.world(mxp, myp)
            ex, ey   = snap(wxp), snap(wyp); sx, sy = self.wall_start
            if abs(ex-sx) >= abs(ey-sy): ey = sy
            else: ex = sx
            pygame.draw.line(world_surf, WALL_SEL,
                             (sx+wx_off, sy+wy_off), (ex+wx_off, ey+wy_off), WALL_T)
        for win in self.windows: win.draw(world_surf, woff)
        for d   in self.doors:   d.draw(world_surf, woff)

        fov_world = pygame.Surface((world_w, world_h), pygame.SRCALPHA)
        fov_world.fill((0, 0, 0, 0))

        if self.recorded and self.frames:
            frame = self.frames[min(self.frame_idx, len(self.frames)-1)]
            for i, src in enumerate(self.enemies):
                if i < len(frame.enemies):
                    ex2, ey2, alive, alert, eang = frame.enemies[i]
                    if not (math.isfinite(ex2) and math.isfinite(ey2)):
                        ex2, ey2 = src.x, src.y
                    tmp = Enemy(ex2, ey2); tmp.alive = alive; tmp.alert = alert
                    tmp.angle = eang if math.isfinite(eang) else 0.0
                else:
                    tmp = src
                tmp.draw(world_surf, woff)
            for tx, ty, tang, tidx in frame.teammates:
                if not (math.isfinite(tx) and math.isfinite(ty)): continue
                tmp = Teammate(tidx, tx, ty)
                tmp.angle = tang if math.isfinite(tang) else 0.0
                tmp.draw(world_surf, woff, self._wall_segs, self._door_gaps,
                         fov_world, self._window_gaps)
        else:
            for en in self.enemies: en.draw(world_surf, woff)

        world_surf.blit(fov_world, (0, 0))

        mxp, myp = pygame.mouse.get_pos()
        if mxp > SIDEBAR_W and myp > PANEL_H:
            wxp, wyp = self.world(mxp, myp)
            if self.tool in (Tool.DOOR, Tool.ENTRY):
                h  = self.guess_horiz(wxp, wyp)
                dt = DoorType.ENTRY if self.tool == Tool.ENTRY else DoorType.ROOM
                Door(wxp, wyp, h, dt).draw(world_surf, woff)
            elif self.tool == Tool.WINDOW:
                Window(wxp, wyp, self.guess_horiz(wxp, wyp)).draw(world_surf, woff)
            elif self.tool == Tool.ENEMY:
                pygame.draw.circle(world_surf, ENEMY_C,
                                   (int(wxp+wx_off), int(wyp+wy_off)), E_RADIUS, 2)

        if z == 1.0:
            canvas.blit(world_surf, (0, 0))
        else:
            scaled = pygame.transform.scale(world_surf,
                         (max(1, int(world_w*z)), max(1, int(world_h*z))))
            canvas.blit(scaled, (ox - int(wx_off*z), oy - int(wy_off*z)))

    def _draw_sidebar(self, sw, sh):
        pygame.draw.rect(self.screen, PANEL_C,
                         pygame.Rect(0, PANEL_H, SIDEBAR_W, sh-PANEL_H))
        pygame.draw.line(self.screen, (55, 55, 65), (SIDEBAR_W, PANEL_H), (SIDEBAR_W, sh))

        tools = [(Tool.SELECT,"Select","S"), (Tool.WALL,"Wall","W"),
                 (Tool.DOOR,"Door","D"),     (Tool.ENTRY,"Entry","E"),
                 (Tool.WINDOW,"Window","N"), (Tool.ENEMY,"Enemy","X")]
        bh = 36; pad = 8; y = PANEL_H+10
        mx, my = pygame.mouse.get_pos()
        for i, (tool, lbl, key) in enumerate(tools):
            r = pygame.Rect(pad, y+i*(bh+4), SIDEBAR_W-pad*2, bh)
            draw_btn(self.screen, r, f"{lbl} [{key}]",
                     active=self.tool==tool, hover=r.collidepoint(mx, my))

        ly = y + len(tools)*(bh+4) + 14
        items = [
            (WALL_C,    "Wall"),
            (WINDOW_C,  "Window"),
            (DOOR_C,    "Door"),
            (DOOR_ENTRY,"Entry"),
            (ENEMY_C,   "Enemy"),
            (TEAM_COLOR,"Teammate"),
        ]
        for col, name in items:
            pygame.draw.rect(self.screen, col, (pad, ly, 12, 12), border_radius=2)
            t = ui.font_tiny.render(name, True, TEXT_DIM)
            self.screen.blit(t, (pad+16, ly-1))
            ly += 16

        pan_tip = "SPACE+drag: pan" if self._is_web else "MMB drag: pan"
        tips = ["LMB: place/select", "RMB: delete", pan_tip,
                "Scroll: zoom", "DEL: rm selected", "SPACE: play/pause", "ESC: select"]
        ty = sh - len(tips)*15 - 8
        for tip in tips:
            t = ui.font_tiny.render(tip, True, TEXT_DIM)
            self.screen.blit(t, (pad, ty)); ty += 15

    def _draw_panel(self, sw, sh):
        pygame.draw.rect(self.screen, PANEL_C, pygame.Rect(0, 0, sw, PANEL_H))
        pygame.draw.line(self.screen, (55, 55, 65), (0, PANEL_H), (sw, PANEL_H))

        t = ui.font_ui.render("CQB Sandbox", True, TEXT_DIM)
        self.screen.blit(t, (sw - t.get_width() - 10, 25))

        mx, my = pygame.mouse.get_pos()
        for rect, lbl, cb in self._panel_buttons():
            active   = ("Play" in lbl and self.playing)
            real_lbl = ("Pause" if self.playing else "Play") if "Play" in lbl else lbl
            draw_btn(self.screen, rect, real_lbl, active=active, hover=rect.collidepoint(mx, my))

        if self._status_timer > 0:
            self._status_timer -= 1
            t = ui.font_sm.render(self._status_msg, True, (160, 220, 160))
            self.screen.blit(t, (sw - t.get_width() - 10, 45))

        sr = self._slider_rect()
        if sr and self.recorded and self.frames:
            draw_slider(self.screen, sr, self.frame_idx, 0, len(self.frames)-1)
            if pygame.mouse.get_pressed()[0] and sr.inflate(0,24).collidepoint(mx,my) and my < PANEL_H:
                frac = max(0, min(1, (mx-sr.x)/sr.w))
                self.frame_idx = int(frac * (len(self.frames)-1))
                self.playing = False

        spr = self._speed_slider_rect()
        if spr:
            lo_log, hi_log = math.log(0.25), math.log(10.0)
            spd_frac = (math.log(self.sim_speed) - lo_log) / (hi_log - lo_log)
            spd_lbl  = ui.font_tiny.render("Speed:", True, TEXT_DIM)
            self.screen.blit(spd_lbl, (spr.x - spd_lbl.get_width() - 4,
                                        spr.centery - spd_lbl.get_height()//2))
            draw_slider(self.screen, spr, spd_frac, 0.0, 1.0)
            if pygame.mouse.get_pressed()[0] and spr.inflate(0,24).collidepoint(mx,my) and my < PANEL_H:
                frac2 = max(0.0, min(1.0, (mx-spr.x)/spr.w))
                self.sim_speed = math.exp(lo_log + frac2*(hi_log - lo_log))

    # Main loop (web uses async so this is desktop only)
    def run(self):
        while True:
            self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)