import math

from constants import GRID, FPS, SIM_SPEED, SPACING, ENEMY_FOV, ENEMY_RANGE
from math_utils import (
    v2len, lerp_ang, angle_diff, angle_in_fov,
    ray_cast, build_wall_segs, get_door_gap_indices, get_window_gap_indices,
)
from entities import Enemy, Teammate, SimFrame


# Room geometry measurement
def _measure_room_from_walls(entry_door, walls, from_point=None):
    ed_cx, ed_cy = entry_door.centre
    wall_segs    = build_wall_segs(walls)
    empty_gaps   = set()
    PROBE        = 4
    MAX_RAY      = GRID * 40

    candidates = [(0, -1), (0, 1)] if entry_door.horizontal else [(-1, 0), (1, 0)]

    if from_point is not None:
        fpx, fpy = from_point
        dx = ed_cx - fpx;  dy = ed_cy - fpy
        best_fwd = max(candidates, key=lambda c: c[0]*dx + c[1]*dy)
    else:
        best_fwd  = candidates[0]
        best_dist = MAX_RAY + 1
        for (fx, fy) in candidates:
            px = ed_cx + fx * PROBE
            py = ed_cy + fy * PROBE
            d  = ray_cast(px, py, math.atan2(fy, fx), MAX_RAY, wall_segs, empty_gaps)
            if d < best_dist:
                best_dist = d
                best_fwd  = (fx, fy)

    fwd_x, fwd_y = best_fwd
    lat_x, lat_y = -fwd_y, fwd_x          # left of forward

    px = ed_cx + fwd_x * PROBE
    py = ed_cy + fwd_y * PROBE

    depth      = min(ray_cast(px, py, math.atan2(fwd_y,  fwd_x),  MAX_RAY, wall_segs, empty_gaps) + PROBE, GRID * 20)
    left_dist  = min(ray_cast(px, py, math.atan2( lat_y,  lat_x), MAX_RAY, wall_segs, empty_gaps),         GRID * 20)
    right_dist = min(ray_cast(px, py, math.atan2(-lat_y, -lat_x), MAX_RAY, wall_segs, empty_gaps),         GRID * 20)

    return {
        'fwd':        (fwd_x, fwd_y),
        'lat':        (lat_x, lat_y),
        'origin':     (ed_cx, ed_cy),
        'depth':      depth,
        'left_dist':  left_dist,
        'right_dist': right_dist,
    }


# Waypoint generation
def _make_waypoints(geo, enemies_local, all_enemies):
    ox, oy = geo['origin']
    fx, fy = geo['fwd']
    lx, ly = geo['lat']
    depth  = geo['depth']
    ld, rd = geo['left_dist'], geo['right_dist']

    WALL_MARGIN = GRID * 0.6
    NEAR_FWD    = GRID * 1.4
    FAR_FWD     = depth - WALL_MARGIN

    man1_off = max(rd - WALL_MARGIN, WALL_MARGIN)
    man2_off = max(ld - WALL_MARGIN, WALL_MARGIN)

    near_l = (ox + fx*NEAR_FWD - lx*man1_off, oy + fy*NEAR_FWD - ly*man1_off)
    near_r = (ox + fx*NEAR_FWD + lx*man2_off, oy + fy*NEAR_FWD + ly*man2_off)
    far_l  = (ox + fx*FAR_FWD  - lx*man1_off, oy + fy*FAR_FWD  - ly*man1_off)
    far_r  = (ox + fx*FAR_FWD  + lx*man2_off, oy + fy*FAR_FWD  + ly*man2_off)

    hold_fwd = depth * 0.33
    hold_l   = (ox + fx*hold_fwd - lx*man1_off, oy + fy*hold_fwd - ly*man1_off)
    hold_r   = (ox + fx*hold_fwd + lx*man2_off, oy + fy*hold_fwd + ly*man2_off)

    trail_fwd = max(hold_fwd - SPACING * 1.5, GRID)
    trail_l   = (ox + fx*trail_fwd - lx*man1_off, oy + fy*trail_fwd - ly*man1_off)
    trail_r   = (ox + fx*trail_fwd + lx*man2_off, oy + fy*trail_fwd + ly*man2_off)

    cx = ox + fx * depth * 0.5
    cy = oy + fy * depth * 0.5

    left_ei, right_ei = [], []
    for idx in enemies_local:
        en  = all_enemies[idx]
        lat = (en.x - ox)*lx + (en.y - oy)*ly
        (left_ei if lat <= 0 else right_ei).append(idx)
    left_ei.sort(key=lambda i: v2len(all_enemies[i].x-near_l[0], all_enemies[i].y-near_l[1]))
    right_ei.sort(key=lambda i: v2len(all_enemies[i].x-near_r[0], all_enemies[i].y-near_r[1]))

    def wp(x, y, a='move'): return (float(x), float(y), a)
    q            = [[], [], [], []]
    thresh       = (ox + fx*NEAR_FWD, oy + fy*NEAR_FWD)
    hold_outside = (ox - fx*SPACING*2, oy - fy*SPACING*2)

    q[0] += [wp(*thresh), wp(*near_l), wp(*far_l), wp(*hold_l)]
    q[1] += [wp(*thresh), wp(*near_r), wp(*far_r), wp(*hold_r)]
    q[2] += [wp(*hold_outside, f'wait_for:0:{NEAR_FWD*0.9:.1f}'), wp(*thresh), wp(*near_l), wp(*trail_l)]
    q[3] += [wp(*hold_outside, f'wait_for:1:{NEAR_FWD*0.9:.1f}'), wp(*thresh), wp(*near_r), wp(*trail_r)]

    ang1 = math.atan2(cy - hold_l[1], cx - hold_l[0])
    ang2 = math.atan2(cy - hold_r[1], cx - hold_r[0])
    idle = [ang1, ang2, ang1 + math.pi/5, ang2 - math.pi/5]

    return q, idle


# Window avoidance nudge
def _nudge_waypoints_from_windows(queues, windows):
    WIN_CLEAR = GRID * 1.2
    for win in windows:
        if win.horizontal:
            wx_c, wy_c, tang = win.x + GRID*0.5, win.y, (1.0, 0.0)
        else:
            wx_c, wy_c, tang = win.x, win.y + GRID*0.5, (0.0, 1.0)
        for man_q in queues:
            for k, (wpx, wpy, act) in enumerate(man_q):
                if act != 'move': continue
                dx = wpx - wx_c; dy = wpy - wy_c
                if math.hypot(dx, dy) < WIN_CLEAR:
                    proj = dx*tang[0] + dy*tang[1]
                    push = WIN_CLEAR - abs(proj)
                    sign = 1 if proj >= 0 else -1
                    man_q[k] = (wpx + tang[0]*push*sign,
                                wpy + tang[1]*push*sign, act)


# Room window list
def _build_room_windows(windows, wall_segs, window_gaps, geo, fx, fy):
    ox, oy = geo['origin']
    depth  = geo['depth']
    rc_x   = ox + fx * depth * 0.5
    rc_y   = oy + fy * depth * 0.5
    result = []
    for win in windows:
        wc_x = win.x + (GRID*0.5 if win.horizontal else 0)
        wc_y = win.y + (0 if win.horizontal else GRID*0.5)
        for k, (p1, p2) in enumerate(wall_segs):
            if k not in window_gaps: continue
            seg_len = v2len(p2[0]-p1[0], p2[1]-p1[1])
            if seg_len < 1: continue
            tx = ((wc_x-p1[0])*(p2[0]-p1[0]) + (wc_y-p1[1])*(p2[1]-p1[1])) / (seg_len**2)
            px = p1[0]+tx*(p2[0]-p1[0]); py = p1[1]+tx*(p2[1]-p1[1])
            if not (0 <= tx <= 1 and v2len(wc_x-px, wc_y-py) < GRID): continue
            cands = [(0., 1.), (0., -1.)] if win.horizontal else [(1., 0.), (-1., 0.)]
            to_cx = rc_x - wc_x; to_cy = rc_y - wc_y
            norm  = max(cands, key=lambda n: n[0]*to_cx + n[1]*to_cy)
            if norm[0]*to_cx + norm[1]*to_cy > 1.0:
                result.append({'cx': wc_x, 'cy': wc_y, 'norm': norm})
            break
    return result


# Single room entry loop
def _run_room(door, room_enemies, enemies, teammates,
              wall_segs, door_gaps, window_gaps,
              walls, windows, frames, max_frames, from_point=None):
    geo       = _measure_room_from_walls(door, walls, from_point=from_point)
    fx, fy    = geo['fwd']
    lx, ly    = geo['lat']
    ed_cx, ed_cy = door.centre
    entry_ang = math.atan2(fy, fx)

    # Kill-LOS gaps: own door + all windows
    own_gap_segs = {k for k, (p1, p2) in enumerate(wall_segs)
                    if k in door_gaps and
                    v2len((p1[0]+p2[0])*0.5 - ed_cx,
                          (p1[1]+p2[1])*0.5 - ed_cy) < GRID * 3}
    kill_gaps  = own_gap_segs | window_gaps
    kill_segs  = list(wall_segs)

    queues, idle_sector = _make_waypoints(geo, room_enemies, enemies)
    _nudge_waypoints_from_windows(queues, windows)

    room_windows = _build_room_windows(windows, wall_segs, window_gaps, geo, fx, fy)

    left_ei, right_ei = [], []
    for idx in room_enemies:
        lat = (enemies[idx].x - ed_cx)*lx + (enemies[idx].y - ed_cy)*ly
        (left_ei if lat <= 0 else right_ei).append(idx)
    sectors = {0: left_ei, 1: right_ei, 2: left_ei, 3: right_ei}

    wp_idx     = [0, 0, 0, 0]
    engage_cnt = [0, 0, 0, 0]
    aim_at     = [None, None, None, None]
    dt         = 1.0 / FPS
    pie_man    = None

    for _ in range(max_frames):
        if all(wp_idx[i] >= len(queues[i]) for i in range(4)):
            break

        # Enemy AI
        for en in enemies:
            if not en.alive: continue
            for t in teammates:
                ang_to_t = math.atan2(t.y - en.y, t.x - en.x)
                if angle_in_fov(ang_to_t, en.angle, ENEMY_FOV):
                    dist = v2len(t.x - en.x, t.y - en.y)
                    if dist < ENEMY_RANGE:
                        hit = ray_cast(en.x, en.y, ang_to_t, dist+1, wall_segs, door_gaps)
                        if hit >= dist - 5: en.alert = True
            if en.alert:
                nearest = min(teammates, key=lambda t: v2len(t.x-en.x, t.y-en.y))
                new_a   = lerp_ang(en.angle,
                                   math.atan2(nearest.y-en.y, nearest.x-en.x), 0.05)
                if math.isfinite(new_a): en.angle = new_a

        # Window pie
        if room_windows:
            best_d  = GRID * 4.0
            pie_man = None
            pie_ang = None
            for i2, t2 in enumerate(teammates):
                if engage_cnt[i2] > 0 or wp_idx[i2] >= len(queues[i2]): continue
                for rw in room_windows:
                    d = v2len(t2.x - rw['cx'], t2.y - rw['cy'])
                    if d < best_d:
                        best_d  = d
                        pie_man = i2
                        pie_ang = math.atan2(rw['norm'][1], rw['norm'][0])
            if pie_man is not None:
                t2 = teammates[pie_man]
                la = lerp_ang(t2.angle, pie_ang, 0.12)
                if math.isfinite(la): t2.angle = la

        # Teammate movement & kill LOS
        for i, t in enumerate(teammates):
            if engage_cnt[i] > 0:
                engage_cnt[i] -= 1
                if aim_at[i] is not None:
                    ax, ay = aim_at[i]
                    la = lerp_ang(t.angle, math.atan2(ay-t.y, ax-t.x), 0.25)
                    if math.isfinite(la): t.angle = la
                continue

            fwd_progress = (t.x - ed_cx)*fx + (t.y - ed_cy)*fy
            if fwd_progress > GRID * 0.5:
                # Sector kill
                for ei in sectors.get(i, []):
                    if ei >= len(enemies) or not enemies[ei].alive: continue
                    en    = enemies[ei]
                    dx_e  = en.x - t.x; dy_e = en.y - t.y
                    dist_e = v2len(dx_e, dy_e)
                    if dist_e < 2: continue
                    aim_e = math.atan2(dy_e, dx_e)
                    los   = ray_cast(t.x, t.y, aim_e, dist_e+1, kill_segs, kill_gaps)
                    if los >= dist_e - 4:
                        en.alive = False; en.alert = False
                        aim_at[i] = (en.x, en.y)
                        engage_cnt[i] = int(FPS * 0.5)
                        break

                # Window kill (pie man only)
                if engage_cnt[i] == 0 and i == pie_man and room_windows:
                    for ei, en in enumerate(enemies):
                        if not en.alive: continue
                        if any(en is enemies[idx] for idx in sectors.get(i, [])): continue
                        dx_e   = en.x - t.x; dy_e = en.y - t.y
                        dist_e = v2len(dx_e, dy_e)
                        if dist_e < 2: continue
                        aim_e  = math.atan2(dy_e, dx_e)
                        los    = ray_cast(t.x, t.y, aim_e, dist_e+1, kill_segs, kill_gaps)
                        if los >= dist_e - 4:
                            en.alive = False; en.alert = False
                            aim_at[i] = (en.x, en.y)
                            engage_cnt[i] = int(FPS * 0.5)
                            break

            if engage_cnt[i] > 0: continue

            if wp_idx[i] >= len(queues[i]):
                la = lerp_ang(t.angle, idle_sector[i], 0.04)
                if math.isfinite(la): t.angle = la
                continue

            tx, ty, action = queues[i][wp_idx[i]]

            if action.startswith('wait_for:'):
                parts    = action.split(':')
                ref_man  = int(parts[1]); req_fwd = float(parts[2])
                progress = (teammates[ref_man].x - ed_cx)*fx + (teammates[ref_man].y - ed_cy)*fy
                if progress >= req_fwd:
                    wp_idx[i] += 1
                else:
                    la = lerp_ang(t.angle, entry_ang, 0.08)
                    if math.isfinite(la): t.angle = la
                continue

            dx = tx - t.x; dy = ty - t.y
            dist = v2len(dx, dy)
            if dist < 5:
                wp_idx[i] += 1
                continue

            move = min(SIM_SPEED * dt, dist)
            ang  = math.atan2(dy, dx)
            if math.isfinite(ang): t.target_angle = ang
            if i != pie_man:
                la = lerp_ang(t.angle, t.target_angle, 0.15)
                if math.isfinite(la): t.angle = la
            nx = t.x + math.cos(ang) * move
            ny = t.y + math.sin(ang) * move
            if math.isfinite(nx) and math.isfinite(ny):
                t.x, t.y = nx, ny

        frames.append(SimFrame(teammates, enemies))


# Top-level entry point
def run_simulation(entry_door, enemies_src, walls, doors, windows):
    if entry_door is None:
        return []

    enemies   = [Enemy(e.x, e.y) for e in enemies_src]
    for ne, e in zip(enemies, enemies_src):
        ne.angle = e.angle

    wall_segs   = build_wall_segs(walls)
    door_gaps   = get_door_gap_indices(wall_segs, doors)
    window_gaps = get_window_gap_indices(wall_segs, windows)

    # Initial spawn
    ed_cx, ed_cy = entry_door.centre
    geo0         = _measure_room_from_walls(entry_door, walls)
    fx0, fy0     = geo0['fwd']
    lx0, ly0     = geo0['lat']
    ld0, rd0     = geo0['left_dist'], geo0['right_dist']
    sdx0, sdy0   = -fx0, -fy0
    longer0      = -1 if ld0 >= rd0 else 1
    dgx = sdx0 + lx0*longer0; dgy = sdy0 + ly0*longer0
    dl  = v2len(dgx, dgy)
    if dl > 0: dgx /= dl; dgy /= dl

    entry_ang0    = math.atan2(fy0, fx0)
    spawn_targets = [(ed_cx + dgx*(i+1)*SPACING,
                      ed_cy + dgy*(i+1)*SPACING) for i in range(4)]
    m1_lat0       = ((spawn_targets[0][0]-ed_cx)*lx0 +
                     (spawn_targets[0][1]-ed_cy)*ly0)
    cant_sign0    = -1 if m1_lat0 >= 0 else 1

    teammates = []
    for i in range(4):
        t = Teammate(i, spawn_targets[i][0], spawn_targets[i][1])
        t.angle = t.target_angle = entry_ang0 + cant_sign0 * 0.18 * i
        teammates.append(t)

    frames       = []
    max_per_room = FPS * 60

    # BFS over rooms
    entry_idx     = next(i for i, d in enumerate(doors) if d is entry_door)
    cleared_doors = {entry_idx}
    pending       = [entry_door]
    pending_from  = [None]
    claimed_rooms = []

    while pending:
        cur_door = pending.pop(0)
        from_pt  = pending_from.pop(0)
        geo      = _measure_room_from_walls(cur_door, walls, from_point=from_pt)

        ox_g, oy_g = geo['origin']
        fx_g, fy_g = geo['fwd']
        depth_g    = geo['depth']
        rc_x       = ox_g + fx_g * depth_g * 0.5
        rc_y       = oy_g + fy_g * depth_g * 0.5

        # Identify wall segs for this door only
        own_door_segs = set()
        dcx, dcy = cur_door.centre
        for k, (p1, p2) in enumerate(wall_segs):
            if k in door_gaps:
                mx = (p1[0]+p2[0])*0.5; my = (p1[1]+p2[1])*0.5
                if v2len(mx - dcx, my - dcy) < GRID * 3:
                    own_door_segs.add(k)

        assign_segs = list(wall_segs)
        assign_open = own_door_segs
        claimed     = {ei for room in claimed_rooms for ei in room}

        room_enemies = []
        for i, e in enumerate(enemies):
            if not e.alive or i in claimed: continue
            dist_ce = v2len(e.x - rc_x, e.y - rc_y)
            if dist_ce < 1: continue
            ang_ce  = math.atan2(e.y - rc_y, e.x - rc_x)
            hit     = ray_cast(rc_x, rc_y, ang_ce, dist_ce+1, assign_segs, assign_open)
            if hit >= dist_ce - 4:
                room_enemies.append(i)
        claimed_rooms.append(room_enemies)

        _run_room(cur_door, room_enemies, enemies, teammates,
                  wall_segs, door_gaps, window_gaps,
                  walls, windows, frames, max_per_room, from_point=from_pt)

        # Room geometry for routing next door
        ox_r, oy_r = geo['origin']
        fx_r, fy_r = geo['fwd']
        lx_r, ly_r = geo['lat']
        depth_r    = geo['depth']
        ld_r, rd_r = geo['left_dist'], geo['right_dist']
        room_cx    = ox_r + fx_r * depth_r * 0.5
        room_cy    = oy_r + fy_r * depth_r * 0.5

        # Aim at next door during hold
        next_door_centre = None
        for j, d in enumerate(doors):
            if j in cleared_doors or d.dtype.value != 'room': continue
            dcx2, dcy2 = d.centre
            rel_x2 = dcx2 - ox_r; rel_y2 = dcy2 - oy_r
            fp2 = rel_x2*fx_r + rel_y2*fy_r
            lp2 = rel_x2*lx_r + rel_y2*ly_r
            on_far = abs(fp2 - depth_r) < GRID*1.5 and -rd_r-GRID <= lp2 <= ld_r+GRID
            on_lat = GRID*0.5 <= fp2 <= depth_r and (abs(lp2+rd_r) < GRID*1.5 or abs(lp2-ld_r) < GRID*1.5)
            if on_far or on_lat:
                next_door_centre = (dcx2, dcy2); break

        if next_door_centre is not None:
            ndcx2, ndcy2 = next_door_centre
            def _next_door_ang(t, i):
                return math.atan2(ndcy2 - t.y, ndcx2 - t.x) + lx_r * 0.12 * i
        else:
            def _next_door_ang(t, i): return t.angle

        for _ in range(FPS // 2):
            for i, t in enumerate(teammates):
                la = lerp_ang(t.angle, _next_door_ang(t, i), 0.06)
                if math.isfinite(la): t.angle = la
            frames.append(SimFrame(teammates, enemies))

        # Find candidate doors
        candidate_doors = []
        for j, d in enumerate(doors):
            if j in cleared_doors or d.dtype.value != 'room': continue
            dcx, dcy   = d.centre
            rel_x      = dcx - ox_r; rel_y = dcy - oy_r
            fwd_proj   = rel_x*fx_r + rel_y*fy_r
            lat_proj   = rel_x*lx_r + rel_y*ly_r
            on_far_wall = abs(fwd_proj - depth_r) < GRID*1.5 and -rd_r-GRID <= lat_proj <= ld_r+GRID
            on_lat_wall = GRID*0.5 <= fwd_proj <= depth_r and (abs(lat_proj+rd_r) < GRID*1.5 or abs(lat_proj-ld_r) < GRID*1.5)
            if on_far_wall or on_lat_wall:
                candidate_doors.append((j, d, fwd_proj, lat_proj))

        def _door_score(cd):
            j2, d2, fp2, lp2 = cd
            dcx2, dcy2 = d2.centre
            ang       = math.atan2(dcy2 - room_cy, dcx2 - room_cx)
            entry_dir = math.atan2(fy_r, fx_r)
            turn      = angle_diff(entry_dir, ang)
            if abs(turn) > math.radians(150): return 1e9
            return abs(turn)

        if candidate_doors:
            candidate_doors.sort(key=_door_score)
            j_best, d_best = candidate_doors[0][0], candidate_doors[0][1]
            cleared_doors.add(j_best)

            next_geo = _measure_room_from_walls(d_best, walls, from_point=(room_cx, room_cy))
            nfx, nfy = next_geo['fwd']
            nlx, nly = next_geo['lat']
            nld, nrd = next_geo['left_dist'], next_geo['right_dist']
            ndcx, ndcy = d_best.centre
            n_sdx, n_sdy = -nfx, -nfy
            longer = -1 if nld >= nrd else 1
            dgx = n_sdx + nlx*longer; dgy = n_sdy + nly*longer
            dl2 = v2len(dgx, dgy)
            if dl2 > 0: dgx /= dl2; dgy /= dl2
            entry_ang = math.atan2(nfy, nfx)

            targets = [(ndcx + dgx*(i+1)*SPACING,
                        ndcy + dgy*(i+1)*SPACING) for i in range(4)]
            m1_lat    = (targets[0][0]-ndcx)*nlx + (targets[0][1]-ndcy)*nly
            cant_sign = -1 if m1_lat >= 0 else 1

            # Re-assign roles by door proximity
            order = sorted(range(4), key=lambda k: v2len(teammates[k].x-ndcx, teammates[k].y-ndcy))
            for new_role, old_idx in enumerate(order):
                teammates[old_idx].idx = new_role
            teammates = [teammates[order[k]] for k in range(4)]

            # Walk to stack
            dt_w     = 1.0 / FPS
            max_walk = FPS * 15
            for _ in range(max_walk):
                all_arrived = True
                for i, t in enumerate(teammates):
                    tx2, ty2 = targets[i]
                    dx2 = tx2 - t.x; dy2 = ty2 - t.y
                    dist2 = v2len(dx2, dy2)
                    if dist2 > 4:
                        all_arrived = False
                        move = min(SIM_SPEED * dt_w, dist2)
                        ang2 = math.atan2(dy2, dx2)
                        if math.isfinite(ang2): t.target_angle = ang2
                        la2  = lerp_ang(t.angle, t.target_angle, 0.15)
                        if math.isfinite(la2): t.angle = la2
                        nx2 = t.x + math.cos(ang2) * move
                        ny2 = t.y + math.sin(ang2) * move
                        if math.isfinite(nx2) and math.isfinite(ny2):
                            t.x, t.y = nx2, ny2
                    else:
                        aim_ang = entry_ang + (0 if i == 0 else cant_sign * 0.15 * i)
                        la2 = lerp_ang(t.angle, aim_ang, 0.1)
                        if math.isfinite(la2): t.angle = la2
                frames.append(SimFrame(teammates, enemies))
                if all_arrived: break

            # Snap to canted stack
            stack_cants = [0.0, cant_sign*0.18, cant_sign*0.32, cant_sign*0.46]
            for i, t in enumerate(teammates):
                t.angle = t.target_angle = entry_ang + stack_cants[i]
            for _ in range(FPS // 3):
                frames.append(SimFrame(teammates, enemies))

            pending.append(d_best)
            pending_from.append((room_cx, room_cy))

    return frames