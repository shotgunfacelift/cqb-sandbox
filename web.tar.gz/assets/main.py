# /// script
# dependencies = ["pygame-ce"]
# ///
import asyncio
import sys
import pygame

pygame.init()

# Read real window size before creating the display
# On desktop this stays at the constant defaults.
# In the browser, read the actual viewport so set_mode matches it exactly
# which means pygame mouse coords == CSS pixel coords with zero offset.
_W, _H = 1440, 860
if sys.platform == "emscripten":
    try:
        from platform import window as _win
        _W = int(_win.innerWidth)
        _H = int(_win.innerHeight)
        # Wire up a JS resize handler so pygame gets VIDEORESIZE when the
        # browser window changes size.  Module.setCanvasSize is the official
        # Emscripten/SDL2 API for this.
        _win.eval("""
            (function(){
                function _cqb_resize(){
                    var w = window.innerWidth|0, h = window.innerHeight|0;
                    if (typeof Module !== 'undefined' && Module.setCanvasSize){
                        Module.setCanvasSize(w, h, true);
                    }
                }
                window.addEventListener('resize', _cqb_resize);
            })();
        """)
    except Exception as e:
        print(f"[size] {e}")

from app import App
app = App(_W, _H)

async def main():
    while True:
        app.handle_events()
        app.update()
        app.draw()
        app.clock.tick(60)
        await asyncio.sleep(0)

asyncio.run(main())