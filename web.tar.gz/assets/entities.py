import math
import pygame

from constants import (
    GRID, WALL_T, DOOR_W, DOOR_H,
    WALL_C, WALL_SEL, DOOR_C, DOOR_ENTRY, WINDOW_C,
    ENEMY_C, ENEMY_DEAD, LASER_C, TEAM_COLOR,
    T_RADIUS, E_RADIUS, DoorType,
)
from math_utils import snap, ray_cast, draw_dashed, v2len


class Wall:
    _id = 0

    def __init__(self, x1, y1, x2, y2):
        Wall._id += 1
        self.id = Wall._id
        self.x1, self.y1 = min(x1, x2), min(y1, y2)
        self.x2, self.y2 = max(x1, x2), max(y1, y2)
        self.selected = False

    @property
    def rect(self):
        w = max(self.x2 - self.x1, WALL_T)
        h = max(self.y2 - self.y1, WALL_T)
        return pygame.Rect(self.x1 - WALL_T // 2, self.y1 - WALL_T // 2,
                           w + WALL_T, h + WALL_T)

    def draw(self, surf, off=(0, 0)):
        r = self.rect.move(*off)
        pygame.draw.rect(surf, WALL_SEL if self.selected else WALL_C, r,
                         border_radius=2)

    def hit(self, mx, my, off=(0, 0)):
        return self.rect.move(*off).inflate(4, 4).collidepoint(mx, my)

    def as_seg(self):
        return ((self.x1, self.y1), (self.x2, self.y2))


class Door:
    _id = 0

    def __init__(self, x, y, horizontal=True, dtype=DoorType.ROOM):
        Door._id += 1
        self.id = Door._id
        self.x, self.y  = snap(x), snap(y)
        self.horizontal = horizontal
        self.dtype      = dtype

    @property
    def centre(self):
        if self.horizontal:
            return (self.x + DOOR_W // 2, self.y)
        return (self.x, self.y + DOOR_W // 2)

    @property
    def rect(self):
        if self.horizontal:
            return pygame.Rect(self.x, self.y - DOOR_H // 2, DOOR_W, DOOR_H)
        return pygame.Rect(self.x - DOOR_H // 2, self.y, DOOR_H, DOOR_W)

    def draw(self, surf, off=(0, 0)):
        r   = self.rect.move(*off)
        col = DOOR_ENTRY if self.dtype == DoorType.ENTRY else DOOR_C
        pygame.draw.rect(surf, col, r, border_radius=3)
        if self.dtype == DoorType.ENTRY:
            pygame.draw.circle(surf, (180, 255, 180), r.center, 5)

    def hit(self, mx, my, off=(0, 0)):
        return self.rect.move(*off).inflate(12, 12).collidepoint(mx, my)


class Window:
    _id = 0

    def __init__(self, x, y, horizontal=True):
        Window._id += 1
        self.id = Window._id
        self.x, self.y, self.horizontal = snap(x), snap(y), horizontal

    @property
    def rect(self):
        if self.horizontal:
            return pygame.Rect(self.x, self.y - 4, GRID, 8)
        return pygame.Rect(self.x - 4, self.y, 8, GRID)

    def draw(self, surf, off=(0, 0)):
        r = self.rect.move(*off)
        pygame.draw.rect(surf, WINDOW_C, r, border_radius=2)
        pygame.draw.rect(surf, (255, 240, 150), r, 2, border_radius=2)

    def hit(self, mx, my, off=(0, 0)):
        return self.rect.move(*off).inflate(10, 10).collidepoint(mx, my)


class Enemy:
    _id = 0

    def __init__(self, x, y):
        Enemy._id += 1
        self.id    = Enemy._id
        self.x, self.y = float(x), float(y)
        self.alive = True
        self.angle = math.pi
        self.alert = False

    def draw(self, surf, off=(0, 0)):
        ox, oy = off
        cx, cy = int(self.x + ox), int(self.y + oy)
        col    = ENEMY_C if self.alive else ENEMY_DEAD
        pygame.draw.circle(surf, col, (cx, cy), E_RADIUS)
        pygame.draw.circle(surf,
                           (255, 255, 255) if self.alive else (70, 70, 70),
                           (cx, cy), E_RADIUS, 2)
        if not self.alive:
            for s in [(-5, -5, 5, 5), (5, -5, -5, 5)]:
                pygame.draw.line(surf, (180, 50, 50),
                                 (cx + s[0], cy + s[1]),
                                 (cx + s[2], cy + s[3]), 2)
        if self.alive and self.alert:
            pygame.draw.circle(surf, (255, 80, 20), (cx, cy), E_RADIUS + 4, 2)

    def hit(self, mx, my, off=(0, 0)):
        ox, oy = off
        return math.hypot(self.x + ox - mx, self.y + oy - my) < E_RADIUS + 5


class Teammate:
    _font = None

    def __init__(self, idx, x, y):
        self.idx          = idx
        self.x, self.y    = float(x), float(y)
        self.angle        = 0.0
        self.target_angle = 0.0

    def draw(self, surf, off, wall_segs, door_gaps, fov_surf, window_gaps=None):
        ox, oy = off
        rx, ry = self.x + ox, self.y + oy
        if not (math.isfinite(rx) and math.isfinite(ry)):
            return
        cx, cy = int(round(rx)), int(round(ry))

        pygame.draw.circle(surf, TEAM_COLOR, (cx, cy), T_RADIUS)
        pygame.draw.circle(surf, (190, 215, 255), (cx, cy), T_RADIUS, 2)

        la         = self.angle if math.isfinite(self.angle) else 0.0
        laser_open = window_gaps if window_gaps is not None else set()
        laser_dist = ray_cast(self.x, self.y, la, GRID * 40, wall_segs, laser_open)
        laser_dist = max(0.0, min(laser_dist, GRID * 40) - WALL_T * 0.5)
        lx = int(round(self.x + math.cos(la) * laser_dist + ox))
        ly = int(round(self.y + math.sin(la) * laser_dist + oy))
        draw_dashed(surf, LASER_C, (cx, cy), (lx, ly))

        # Font(None) uses built-in font
        if Teammate._font is None:
            Teammate._font = pygame.font.Font(None, 17)
        lbl = Teammate._font.render(str(self.idx + 1), True, (255, 255, 255))
        surf.blit(lbl, (cx - lbl.get_width() // 2, cy - lbl.get_height() // 2))


class SimFrame:
    def __init__(self, teammates, enemies):
        def safe(v, fb=0.0):
            return v if math.isfinite(v) else fb

        self.teammates = [(safe(t.x), safe(t.y), safe(t.angle), t.idx)
                          for t in teammates]
        self.enemies   = [(safe(e.x), safe(e.y), e.alive, e.alert, safe(e.angle))
                          for e in enemies]