import math
from enum import Enum, auto

# Screen
SCREEN_W, SCREEN_H = 1440, 860
GRID     = 40
WALL_T   = 6
FPS      = 60

# Colors
BG         = ( 28,  28,  34)
GRID_C     = ( 44,  44,  52)
WALL_C     = (175, 170, 155)
WALL_SEL   = (255, 220,  70)
DOOR_C     = ( 255, 195, 70)
DOOR_ENTRY = ( 70, 240, 130)
WINDOW_C   = ( 80, 190, 255)
ENEMY_C    = (220,  55,  55)
ENEMY_DEAD = ( 85,  35,  35)
LASER_C    = (255,  60,  60)
PANEL_C    = ( 18,  18,  24)
BTN_C      = ( 52,  52,  62)
BTN_HOV    = ( 70,  70,  84)
BTN_ACT    = ( 72, 130, 195)
TEXT_C     = (215, 215, 215)
TEXT_DIM   = (120, 120, 132)
TEAM_COLOR = ( 80, 160, 255)

# Sizes/physics
T_RADIUS  = 10
E_RADIUS  = 11
DOOR_W    = GRID
DOOR_H    = 10
PANEL_H   = 70
SIDEBAR_W = 168
SIM_SPEED = 80.0
SPACING   = 30

# LOS/FOV
FOV_HALF    = math.radians(50)
FOV_RANGE   = 220
ENEMY_FOV   = math.radians(55)
ENEMY_RANGE = 180

# Enums
class Tool(Enum):
    SELECT = auto(); WALL   = auto(); DOOR  = auto()
    ENTRY  = auto(); WINDOW = auto(); ENEMY = auto()

class DoorType(Enum):
    ROOM  = "room"
    ENTRY = "entry"