import math
import pygame
from constants import GRID, WALL_T


def snap(v):
    return round(v / GRID) * GRID

def v2len(dx, dy):
    return math.hypot(dx, dy)

def v2norm(dx, dy):
    l = v2len(dx, dy)
    return (dx / l, dy / l) if l else (0.0, 0.0)

def angle_diff(a, b):
    return (b - a + math.pi) % math.tau - math.pi

def lerp_ang(a, b, t):
    return a + angle_diff(a, b) * t

def angle_in_fov(target_ang, facing, half_fov):
    return abs(angle_diff(facing, target_ang)) <= half_fov


def seg_intersect(ax, ay, bx, by, cx, cy, dx, dy):
    r = (bx - ax, by - ay)
    s = (dx - cx, dy - cy)
    rxs = r[0] * s[1] - r[1] * s[0]
    if abs(rxs) < 1e-9:
        return None
    qp = (cx - ax, cy - ay)
    t  = (qp[0] * s[1] - qp[1] * s[0]) / rxs
    u  = (qp[0] * r[1] - qp[1] * r[0]) / rxs
    if 0 <= t <= 1 and 0 <= u <= 1:
        return t, u
    return None


def ray_cast(ox, oy, angle, max_dist, wall_segs, door_gaps):
    dx, dy = math.cos(angle), math.sin(angle)
    ex, ey = ox + dx * max_dist, oy + dy * max_dist
    best   = max_dist
    for i, (p1, p2) in enumerate(wall_segs):
        if i in door_gaps:
            continue
        res = seg_intersect(ox, oy, ex, ey, p1[0], p1[1], p2[0], p2[1])
        if res:
            hit = res[0] * max_dist
            if math.isfinite(hit):
                best = min(best, hit)
    return best


def build_wall_segs(walls):
    return [((w.x1, w.y1), (w.x2, w.y2)) for w in walls]


def get_door_gap_indices(wall_segs, doors):
    gaps = set()
    for d in doors:
        dc = (d.x + GRID // 2, d.y) if d.horizontal else (d.x, d.y + GRID // 2)
        for i, (p1, p2) in enumerate(wall_segs):
            seg_len = v2len(p2[0] - p1[0], p2[1] - p1[1])
            if seg_len < 1:
                continue
            tx = ((dc[0] - p1[0]) * (p2[0] - p1[0]) +
                  (dc[1] - p1[1]) * (p2[1] - p1[1])) / (seg_len ** 2)
            px = p1[0] + tx * (p2[0] - p1[0])
            py = p1[1] + tx * (p2[1] - p1[1])
            if 0 <= tx <= 1 and v2len(dc[0] - px, dc[1] - py) < GRID:
                gaps.add(i)
    return gaps


def get_window_gap_indices(wall_segs, windows):
    gaps = set()
    for w in windows:
        wc = (w.x + GRID // 2, w.y) if w.horizontal else (w.x, w.y + GRID // 2)
        for i, (p1, p2) in enumerate(wall_segs):
            seg_len = v2len(p2[0] - p1[0], p2[1] - p1[1])
            if seg_len < 1:
                continue
            tx = ((wc[0] - p1[0]) * (p2[0] - p1[0]) +
                  (wc[1] - p1[1]) * (p2[1] - p1[1])) / (seg_len ** 2)
            px = p1[0] + tx * (p2[0] - p1[0])
            py = p1[1] + tx * (p2[1] - p1[1])
            if 0 <= tx <= 1 and v2len(wc[0] - px, wc[1] - py) < GRID:
                gaps.add(i)
    return gaps


def draw_dashed(surf, col, p1, p2, dash=8, gap=5, width=2):
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    dist   = math.hypot(dx, dy)
    if dist < 1:
        return
    nx, ny = dx / dist, dy / dist
    pos, on = 0.0, True
    while pos < dist:
        nxt = min(pos + (dash if on else gap), dist)
        if on:
            pygame.draw.line(surf, col,
                             (p1[0] + nx * pos,  p1[1] + ny * pos),
                             (p1[0] + nx * nxt,  p1[1] + ny * nxt), width)
        pos, on = nxt, not on